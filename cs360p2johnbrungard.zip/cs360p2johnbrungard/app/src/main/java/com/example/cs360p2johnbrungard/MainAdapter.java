package com.example.cs360p2johnbrungard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

/* Used to inflate contents of ArrayList onto UI/ListView for main screen */
public class MainAdapter extends ArrayAdapter<Item> {
    public MainAdapter(Context context, List<Item> item) {
        super(context, 0, item);
    }

    // Converts view to project content from data xml to main xml
    @NonNull
    @Override
    public View getView (int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Item inventoryItem = getItem(position);


        if (convertView == null) {
            // Inflate data xml onto ListView in main xml
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.data_main_inventory, parent, false);
        }

        // Row components
        Button deleteBtn = convertView.findViewById(R.id.deleteBtn);
        deleteBtn.setOnLongClickListener(view -> false);

        Button editBtn = convertView.findViewById(R.id.editBtn);
        editBtn.setOnLongClickListener(view -> false);


        TextView name = convertView.findViewById(R.id.fillName);
        TextView count = convertView.findViewById(R.id.fillCount);
        TextView date = convertView.findViewById(R.id.fillDate);

        name.setText(inventoryItem.getName());
        count.setText(inventoryItem.getCount());
        date.setText(inventoryItem.getDate());

        return convertView;
    }
}