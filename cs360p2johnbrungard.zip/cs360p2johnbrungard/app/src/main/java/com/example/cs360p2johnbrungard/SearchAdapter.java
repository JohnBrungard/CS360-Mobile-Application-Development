package com.example.cs360p2johnbrungard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

/* Used to inflate contents of ArrayList onto UI/ListView for search screen */
public class SearchAdapter extends ArrayAdapter<Item> {
    public SearchAdapter(Context context, List<Item> item) {
        super(context, 0, item);
    }

    // Converts view to project content from data xml to search xml
    @NonNull
    @Override
    public View getView (int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Item item = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.data_search_inventory, parent, false);
        }

        // Row components
        TextView name = convertView.findViewById(R.id.name);
        TextView count = convertView.findViewById(R.id.count);
        TextView date = convertView.findViewById(R.id.date);

        name.setText(item.getName());
        count.setText(item.getCount());
        date.setText(item.getDate());

        return convertView;
    }
}