package com.example.cs360p2johnbrungard;

import java.util.ArrayList;

/* Holds constructor, setters, and getters for attributes of an Item */
public class Item {

    // ArrayLists used for CRUD operations from Database
    public static ArrayList<Item>itemArrayList = new ArrayList<>();
    public static ArrayList<Item>allItemArrayList = new ArrayList<>();
    public static ArrayList<Item>zeroCountArrayList = new ArrayList<>();

    // Variables associated with an Item object
    private long id;
    private String name;
    private final String count;
    private final String date;

    public Item(long id, String name, String count, String date) {
        this.id = id;
        this.name = name;
        this.count = count;
        this.date = date;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCount() {
        return count;
    }

    public String getDate() {
        return date;
    }

}
