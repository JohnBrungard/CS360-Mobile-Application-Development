package com.example.cs360p2johnbrungard;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/* Sets SMS Permissions and sends message of granted permission and low inventory counts */
public class PermissionsActivity extends AppCompatActivity {
    // Key variable initializations
    SwitchCompat smsSwitch;
    private PendingIntent pendingIntent;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_permissions);

        // Switch assignment
        smsSwitch = findViewById(R.id.smsSwitch);

        // Retrieve a PendingIntent that will perform a broadcast
        Intent alarmIntent = new Intent(PermissionsActivity.this, AlarmReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(PermissionsActivity.this, 0, alarmIntent, PendingIntent.FLAG_IMMUTABLE);

        // SharedPreferences will save the state of the switch when leaving the activity
        SharedPreferences sharedPreferences = getSharedPreferences("save", MODE_PRIVATE);
        smsSwitch.setChecked(sharedPreferences.getBoolean("value", false));

        // When switch is toggled
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = getSharedPreferences("save", MODE_PRIVATE).edit();
            // off
            if (!isChecked) {
                // Updates SharedPreferences of state
                editor.putBoolean("value", false);
                editor.apply();
                smsSwitch.setChecked(false);

                // Cancel alarm to send SMS messages
                cancel();
            }
            // on
            else {
                // Updates SharedPreferences of state
                editor.putBoolean("value", true);
                editor.apply();
                smsSwitch.setChecked(true);

                // If user has granted permission to receive SMS messages
                if (ContextCompat.checkSelfPermission(PermissionsActivity.this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
                    // Alert user on app that permission was granted
                    Toast.makeText(PermissionsActivity.this, "You have been given permission to receive SMS messages from B.I.S."
                            , Toast.LENGTH_SHORT).show();

                    // Send SMS to welcome user and test SMS messaging
                    sendSms();

                    // Start the alarm so user receives SMS messages in interval
                    start();

                }
                // If user has not made a decision on their permissions
                else {
                    // Make popup appear asking if user would like to receive messages
                    ActivityCompat.requestPermissions(PermissionsActivity.this, new String[]{ Manifest.permission.SEND_SMS }, 100);

                    // If user chooses not to provide permission: switch stays off
                    if (ContextCompat.checkSelfPermission(PermissionsActivity.this, Manifest.permission.SEND_SMS)
                            != PackageManager.PERMISSION_GRANTED) {
                        // Updates SharedPreferences of state
                        editor.putBoolean("value", false);
                        editor.apply();
                        smsSwitch.setChecked(false);
                    }
                }

            }
        });
    }

    // Delivers the request for users to approve or deny permission for SMS
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // If the user accepts to receive notifications
        if (requestCode == 100 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            SharedPreferences.Editor editor = getSharedPreferences("save", MODE_PRIVATE).edit();
            editor.putBoolean("value", true);
            editor.apply();
            smsSwitch.setChecked(true);
        }
        // If user denies to receive notifications
        else {
            // Alert user they will not receive messages
            Toast.makeText(PermissionsActivity.this, "To get messages, you must allow SMS Messages from B.I.S. in your settings"
                    , Toast.LENGTH_SHORT).show();
        }
    }

    // Sends an SMS message when user wants to receive notifications
    protected void sendSms() {
        SmsManager smsManager = SmsManager.getDefault();
        String phone = "+1 555-123-4567";
        String message =  "You have now accepted to receive SMS notifications from B.I.S.!";

        smsManager.sendTextMessage(phone, null, message, null, null);
    }

    // Assigns an alarm that will send an SMS at the indicated interval
    public void start() {
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        int minutes = 1;
        int interval = 1000 * 60 * minutes;

        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntent);
        Toast.makeText(this, "Alarm Set", Toast.LENGTH_SHORT).show();
    }

    // Cancels the alarm so user no longer receives SMS messages
    public void cancel() {
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pendingIntent);
        Toast.makeText(this, "Alarm Canceled", Toast.LENGTH_SHORT).show();
    }

    // Called when an activity is no longer paused or is first starting up
    @Override
    protected void onStart() {
        super.onStart();

        // Ensures the switch stays off if user has not granted permission for SMS
        // Used because of a bug involving changing permissions while on PermissionsActivity.xml
        if (ContextCompat.checkSelfPermission(PermissionsActivity.this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            SharedPreferences.Editor editor = getSharedPreferences("save", MODE_PRIVATE).edit();
            // Updates SharedPreferences of state
            editor.putBoolean("value", false);
            editor.apply();
            smsSwitch.setChecked(false);
        }
    }

    // Makes app bar and its components appear
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.permissions_menu, menu);
        return true;
    }

    // Controls navigation through the app bar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            Intent intentLogout = new Intent(this, LoginActivity.class);
            startActivity(intentLogout);
            return true;
        }
        else if (item.getItemId() == R.id.moreInfo) {
            // Alert user
            Toast.makeText(PermissionsActivity.this, "For more information on B.I.S.: www.fakeDomain.com!"
                    , Toast.LENGTH_LONG).show();
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }
}
