package com.example.cs360p2johnbrungard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* Stores validated user credentials for logging into the application */
public class LoginDatabase extends SQLiteOpenHelper{
    // Names the database and version
    private static final String DBNAME = "Login.db";
    private static final int VERSION = 1;

    // Constructor
    public LoginDatabase(Context context) {
        super(context, DBNAME, null, VERSION);
    }

    // Declares variables used in database
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_USER = "username";
        private static final String COL_PASS = "password";
    }
    // Creates the database table for storing values
    @Override
    public void onCreate(SQLiteDatabase loginDB) {
        loginDB.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_USER + " text primary key, " +
                UserTable.COL_PASS + " text)");
    }

    // Deletes existing table to create upgraded version
    @Override
    public void onUpgrade(SQLiteDatabase loginDB, int older, int newer) {
        loginDB.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(loginDB);
    }

    // Inserts username and password into database table
    public boolean insertCredentials(String username, String password) {
        SQLiteDatabase loginDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(UserTable.COL_USER, username);
        values.put(UserTable.COL_PASS, password);

        long results = loginDB.insert(UserTable.TABLE, null, values);

        return results != -1;
    }

    // Authenticates if user is already in database when registering
    public boolean checkUsername (String username) {
        SQLiteDatabase loginDB = this.getReadableDatabase();
        Cursor cursor = loginDB.rawQuery("Select * from " + UserTable.TABLE + " where username = ?",
                new String[] { username });

        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        else {
            cursor.close();
            return false;
        }
    }

    // Authenticates username and password of existing user when logging in
    public boolean checkPassword (String username, String password) {
        SQLiteDatabase loginDB = this.getReadableDatabase();
        Cursor cursor = loginDB.rawQuery("Select * from " + UserTable.TABLE + " where username = ? and " +
                "password = ?", new String[] { username, password });

        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        else {
            cursor.close();
            return false;
        }
    }
}
