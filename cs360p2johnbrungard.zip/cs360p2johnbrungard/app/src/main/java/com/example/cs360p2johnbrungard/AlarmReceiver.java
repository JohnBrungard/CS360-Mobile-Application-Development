package com.example.cs360p2johnbrungard;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

/* When user chooses to receive SMS messages and SMS switch is on, user will receive
 * messages in interval concerning an inventory item(s) having a count of 0
 */
public class AlarmReceiver extends BroadcastReceiver {
    InventoryDatabase DB;
    long itemId;
    String itemName;
    @Override
    public void onReceive(Context context, Intent intent) {
        DB = new InventoryDatabase(context.getApplicationContext());
        DB.checkCount();

        // A message is only sent if an inventory item(s) is low
        if (Item.zeroCountArrayList.size() >= 1) {
            StringBuilder message = new StringBuilder("The following items are out of stock:\n\n");

            for (int i = 0; i < Item.zeroCountArrayList.size(); i++) {
                itemId = Item.zeroCountArrayList.get(i).getId();
                itemName = Item.zeroCountArrayList.get(i).getName();

                message.append(itemName).append(" (ID #").append(itemId).append(")\n");
            }

            message.append("\nThank you for using B.I.S.!");

            SmsManager smsManager = SmsManager.getDefault();
            String phone = "+1 555-123-4567";

            smsManager.sendTextMessage(phone, null, message.toString(), null, null);

            Item.zeroCountArrayList.clear();
        }
    }
}
