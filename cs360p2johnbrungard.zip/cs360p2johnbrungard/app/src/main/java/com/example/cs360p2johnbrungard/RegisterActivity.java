package com.example.cs360p2johnbrungard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* Performs validations for registering users via database */
public class RegisterActivity extends AppCompatActivity {
    // Initialize key variables
    EditText username, password, checkPassword;
    Button register;
    LoginDatabase DB;
    boolean checkUser, insert;
    Pattern lowerLetter, upperLetter, digit;
    Matcher hasLowerLetter, hasUpperLetter, hasDigit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hides app bar for signup screen
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.activity_main_register);

        // EditText assignments
        username = findViewById(R.id.registerUsername);
        password = findViewById(R.id.registerPassword);
        checkPassword = findViewById(R.id.retypePassword);

        // Button assignment
        register = findViewById(R.id.registerButton);

        // DB object assignment
        DB = new LoginDatabase(this);

        // When the user clicks the register button
        register.setOnClickListener(view -> {
            // EditTexts are converted to Strings.
            String uName = username.getText().toString();
            String pWord = password.getText().toString();
            String chkPWord = checkPassword.getText().toString();

            // Patterns are declared to check password strength during matcher.
            lowerLetter = Pattern.compile("[a-z]");
            upperLetter = Pattern.compile("[A-Z]");
            digit = Pattern.compile ("\\d");

            // Matchers verify password strength
            hasLowerLetter = lowerLetter.matcher(pWord);
            hasUpperLetter = upperLetter.matcher(pWord);
            hasDigit = digit.matcher(pWord);

            // If username EditText is empty
            if (uName.equals("")) {
                Toast.makeText(RegisterActivity.this, "Username Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If password EditText is empty
            else if (pWord.equals("")) {
                Toast.makeText(RegisterActivity.this, "Password Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If retype password EditText is empty
            else if (chkPWord.equals("")) {
                Toast.makeText(RegisterActivity.this, "Retype Password Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If password does not meet criteria
            else if (pWord.length() < 8 || !hasLowerLetter.find() || !hasUpperLetter.find() ||
            !hasDigit.find()) {
                Toast.makeText(RegisterActivity.this, "Password Does NOT Meet Criteria!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If password is NOT empty and meets requirements
            else {
                // If password and retype password field do NOT match
                if (!pWord.equals(chkPWord)) {
                    // Notify user to recheck their input
                    Toast.makeText(RegisterActivity.this, "Passwords Do Not Match!"
                            , Toast.LENGTH_SHORT).show();
                }
                // If password and retype password fields match
                else {
                    // Handles registration through the database
                    registerThread(uName, pWord, DB);

                }

            }

        });
    }
    public void registerThread (String user, String pass, LoginDatabase database) {
        // Database checks if username already exists
        checkUser = database.checkUsername(user);

        // If the username exists in the DB
        if (checkUser) {
            RegisterActivity.this.runOnUiThread(() -> {
                // Notify user so they can make a different username
                Toast.makeText(RegisterActivity.this, user +" Already Exists!"
                        , Toast.LENGTH_SHORT).show();
            });
        }
        // If the username does not exist in the DB
        else {
            // Inserts new credentials into DB
            insert = database.insertCredentials(user, pass);

            // If the insertion has problems
            if (!insert) {
                RegisterActivity.this.runOnUiThread(() -> {
                    // Notify user of failure
                    Toast.makeText(RegisterActivity.this, "Registration Failed!"
                            , Toast.LENGTH_SHORT).show();
                });
            }
            // If insertion had no found problems
            else {
                RegisterActivity.this.runOnUiThread(() -> {
                    // Notify user of success
                    Toast.makeText(RegisterActivity.this,
                            "User Registered! Please Sign In.",
                            Toast.LENGTH_SHORT).show();

                    // Direct user to logins screen to input successful credentials
                    Intent intent = new Intent (getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                });
            }
        }

    }
}