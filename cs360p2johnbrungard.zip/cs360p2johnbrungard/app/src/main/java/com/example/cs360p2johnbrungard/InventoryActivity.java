package com.example.cs360p2johnbrungard;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Objects;

/* Handles the CRUD operations of the Inventory Management App */
public class InventoryActivity extends AppCompatActivity {
    // Key variable initializations
    EditText addName, addCount, editCount;
    TextView searchNav, helpNav, moreNav;
    Button submitBtn, updateBtn;
    boolean checkName, deleteSuccess, updateSuccess;
    long insert;

    ImageView backArrowAdd, backArrowEdit;
    FloatingActionButton addFab;
    ListView inventoryList;
    LinearLayout addScreen, listHeader, updateScreen;
    InventoryDatabase DB;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hides the home-up button as it is not needed for home/inventory screen
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(false);
        setContentView(R.layout.activity_main_inventory);

        // EditText Assignments
        addName = findViewById(R.id.itemName);
        addCount = findViewById(R.id.itemCount);
        editCount = findViewById(R.id.updateCount);

        // TextView Assignments
        searchNav = findViewById(R.id.searchNav);
        helpNav = findViewById(R.id.helpNav);
        moreNav = findViewById(R.id.moreNav);

        // ImageView Assignments
        backArrowAdd = findViewById(R.id.backArrowAdd);
        backArrowEdit = findViewById(R.id.backArrowEdit);

        // Button assignments
        addFab = findViewById(R.id.floatingActionButton);
        submitBtn = findViewById(R.id.submitButton);
        updateBtn = findViewById(R.id.updateButton);

        // Layout assignments
        inventoryList = findViewById(R.id.inventoryList);
        addScreen = findViewById(R.id.addScreen);
        listHeader = findViewById(R.id.inventoryHeaders);
        updateScreen = findViewById(R.id.updateScreen);

        // DB object assignment
        DB = new InventoryDatabase(this);

        // Makes the add item view popup and other interfering views disappear
        addFab.setOnClickListener(view -> {
            inventoryList.setVisibility(View.INVISIBLE);
            addScreen.setVisibility(View.VISIBLE);
            addFab.setVisibility(View.INVISIBLE);
            listHeader.setVisibility(View.INVISIBLE);
        });

        // Performs validations and an insertion into the database
        submitBtn.setOnClickListener(view -> {
            String itemName = addName.getText().toString();
            String itemCount = addCount.getText().toString();

            // If itemName EditText is empty
            if (itemName.equals("")) {
                Toast.makeText(InventoryActivity.this, "Name Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If itemCount EditText is empty
            else if (itemCount.equals("")) {
                Toast.makeText(InventoryActivity.this, "Count Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If fields are at or below their max length
            else if (itemName.length() > 20 || itemCount.length() > 7) {
                Toast.makeText(InventoryActivity.this, "One Or More Fields are Incorrectly" +
                                " Formatted!"
                        , Toast.LENGTH_SHORT).show();
            }
            else if (itemCount.length() > 1 && itemCount.indexOf("0") == 0) {
                Toast.makeText(InventoryActivity.this, "Number Cannot Begin With 0!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If all fields contain content and meet requirements
            else {
                // Add item into database using background thread
                addItemThread(itemName, itemCount, DB);
            }
        });

        // Pressing search takes user to search inventory screen
        searchNav.setOnClickListener(view -> {
            // User is redirected to search screen
            Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
            startActivity(intent);
        });

        // Pressing help allows users to reach out about issues/improvements
        helpNav.setOnClickListener(view -> Toast.makeText(InventoryActivity.this, "For issues, contact help at " +
                        "johnbrungard50@gmail.com"
                , Toast.LENGTH_LONG).show());

        // If app is further pursued, other features will be added
        moreNav.setOnClickListener(view -> {
            // Notify user so they can make a different item
            Toast.makeText(InventoryActivity.this, "More Features Coming Soon!"
                    , Toast.LENGTH_SHORT).show();
        });

        // Provides additional way to revert to main screen from the add item screen
        backArrowAdd.setOnClickListener(view -> {
            inventoryList.setVisibility(View.VISIBLE);
            addScreen.setVisibility(View.INVISIBLE);
            addFab.setVisibility(View.VISIBLE);
            listHeader.setVisibility(View.VISIBLE);

            addName.setText("");
            addCount.setText("");
        });

        // Provides additional way to revert to main screen from the edit count screen
        backArrowEdit.setOnClickListener(view -> {
            // Return user's view to the main screen
            inventoryList.setVisibility(View.VISIBLE);
            updateScreen.setVisibility(View.INVISIBLE);
            addFab.setVisibility(View.VISIBLE);
            listHeader.setVisibility(View.VISIBLE);

            editCount.setText("");
        });

        // Listener that responds to changes for each row in ListView
        inventoryList.setOnItemLongClickListener((arg0, arg1, pos, id) -> {
            // Retrieves the ID from the item which triggered listener
            long getSelectedId = Item.allItemArrayList.get(pos).getId();
            String getSelectedName = Item.allItemArrayList.get(pos).getName();

            // If the delete button in a row was pressed
            if (arg1.getId() == R.id.deleteBtn) {
                // Alert Dialog will appear when user attempts to delete an item
                new AlertDialog.Builder(this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Are you sure you want to delete this item?")
                        .setMessage(getSelectedName + " will no longer exist in the Database")
                        // If user chooses to delete the item
                        .setPositiveButton("Yes", (dialogInterface, i) -> deleteItemThread(getSelectedId, pos, DB))
                        // If user chooses to not delete the item
                        .setNegativeButton("No", (dialogInterface, i) -> {
                            //set what should happen when negative button is clicked
                            Toast.makeText(InventoryActivity.this, "Nothing Happened", Toast.LENGTH_SHORT).show();
                        })
                        .show();
            }
            // If edit button in a row was pressed
            else if (arg1.getId() == R.id.editBtn) {
                // Make edit screen popup and make interfering screens disappear
                inventoryList.setVisibility(View.INVISIBLE);
                updateScreen.setVisibility(View.VISIBLE);
                addFab.setVisibility(View.INVISIBLE);
                listHeader.setVisibility(View.INVISIBLE);

                // If updateBtn is pressed
                updateBtn.setOnClickListener(view -> {
                    // Get user input from the EditText
                    String newCount = editCount.getText().toString();

                    // If input is empty
                    if (newCount.equals("")) {
                        // Alert user
                        Toast.makeText(InventoryActivity.this, "Field Cannot Be Empty!"
                                , Toast.LENGTH_SHORT).show();
                    }
                    // If input exceeds the millionths place
                    else if (newCount.length() > 7) {
                        // Alert user
                        Toast.makeText(InventoryActivity.this, "Max Limit Exceeded!"
                                , Toast.LENGTH_SHORT).show();
                    }
                    else if (newCount.length() > 1 && newCount.indexOf("0") == 0) {
                        Toast.makeText(InventoryActivity.this, "Number Cannot Begin With 0!"
                                , Toast.LENGTH_SHORT).show();
                    }
                    // If user input meets criteria for a new count
                    else {
                        // Edit the count of an item in the database using background thread
                        editItemThread(getSelectedId, newCount, DB);
                    }
                });
            }


            return true;
        });
    }

    // Sets adapter to project ArrayList contents onto ListView
    private void setAllItemAdapter() {
        MainAdapter mainAdapter = new MainAdapter(getApplicationContext(), Item.allItemArrayList);
        inventoryList.setAdapter(mainAdapter);
    }

    // Refreshes/empties ArrayList to avoid duplicates
    private void clearAdapter() {
        MainAdapter mainAdapter = (MainAdapter) inventoryList.getAdapter();
        mainAdapter.clear();
        mainAdapter.notifyDataSetChanged();
    }

    // Refreshed/empties ArrayList when activity is stopped
    @Override
    protected void onStop() {
        super.onStop();
        clearAdapter();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Queries for all contents in Inventory Database and adds them to ArrayList
        DB.readAll();
        // Sets the adapter using contents of ArrayList to project onto UI.
        setAllItemAdapter();
    }

    // Inflates the app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            Intent intentLogout = new Intent(this, LoginActivity.class);
            startActivity(intentLogout);
            return true;
        }
        else if (item.getItemId() == R.id.permissions) {
            Intent intentPer = new Intent(this, PermissionsActivity.class);
            startActivity(intentPer);
            return true;
        }
        else if (item.getItemId() == R.id.moreInfo) {
            // Alert user
            Toast.makeText(InventoryActivity.this, "For more information on B.I.S.: www.fakeDomain.com!"
                    , Toast.LENGTH_LONG).show();
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }

    public void addItemThread (String name, String num, InventoryDatabase database) {
        Thread thread = new Thread (() -> {
            // Check if the name of an item does not already exist to avoid dupes.
            checkName = database.checkName(name);

            // If the item does exist in the DB
            if (checkName) {
                InventoryActivity.this.runOnUiThread(() -> {
                    // Notify user so they can make a different item
                    Toast.makeText(InventoryActivity.this, name +" Already Exists!"
                            , Toast.LENGTH_SHORT).show();
                });
            }
            // If the item's name does not exist in the DB
            else {
                // Inserts new name and count into DB
                insert = database.createItem(name, num);

                // If the insertion has no problems
                if (insert != -1) {
                    InventoryActivity.this.runOnUiThread(() -> {
                        // Notify user of success
                        Toast.makeText(InventoryActivity.this,
                                "Item Added!",
                                Toast.LENGTH_SHORT).show();

                        // Clears adapter, repopulates ArrayList, and projects results on UI.
                        clearAdapter();
                        DB.readAll();
                        setAllItemAdapter();

                        // Clear EditTexts for quicker insertions
                        addName.setText("");
                        addCount.setText("");

                        // Return user's view to main screen
                        inventoryList.setVisibility(View.VISIBLE);
                        addScreen.setVisibility(View.INVISIBLE);
                        addFab.setVisibility(View.VISIBLE);
                        listHeader.setVisibility(View.VISIBLE);
                    });
                }
                // If insertion had a problem
                else {
                    InventoryActivity.this.runOnUiThread(() -> {
                        // Notify user of failure
                        Toast.makeText(InventoryActivity.this, "Creation Failed!"
                                , Toast.LENGTH_SHORT).show();
                    });
                }
            }

        });
        thread.start();
    }

    public void deleteItemThread (long id, int position, InventoryDatabase database) {
        Thread thread = new Thread(() -> {
            // Delete the item information in button's respective row
            deleteSuccess = database.removeItem(id);

            // If delete operations were successful
            if (deleteSuccess) {
                InventoryActivity.this.runOnUiThread(() -> {
                    // Remove item from ArrayList and refresh Adapter & UI
                    Item.allItemArrayList.remove(position);
                    MainAdapter mainAdapter = (MainAdapter) inventoryList.getAdapter();
                    mainAdapter.notifyDataSetChanged();
                });
            }
            // If delete operations were NOT successful
            else {
                InventoryActivity.this.runOnUiThread(() -> Toast.makeText(InventoryActivity.this, "Something Went Wrong!"
                        , Toast.LENGTH_SHORT).show());
            }

        });
        thread.start();
    }

    public void editItemThread(long id, String count, InventoryDatabase database) {
        Thread thread = new Thread(() -> {
            // Update the item's count in button's respective row
            updateSuccess = database.updateCount(id, count);

            // If update operations were successful
            if (updateSuccess) {
                InventoryActivity.this.runOnUiThread(() -> {
                    // Clears adapter, repopulates ArrayList, and projects results on UI.
                    clearAdapter();
                    DB.readAll();
                    setAllItemAdapter();

                    // Set EditText box to empty text for additional updates
                    editCount.setText("");

                    // Return user's view to the main screen
                    inventoryList.setVisibility(View.VISIBLE);
                    updateScreen.setVisibility(View.INVISIBLE);
                    addFab.setVisibility(View.VISIBLE);
                    listHeader.setVisibility(View.VISIBLE);

                    // Alert user of success
                    Toast.makeText(InventoryActivity.this, "Update Success!"
                            , Toast.LENGTH_SHORT).show();
                });
            }
            // If update operations failed
            else {
                InventoryActivity.this.runOnUiThread(() -> Toast.makeText(InventoryActivity.this, "Update Failed!"
                        , Toast.LENGTH_SHORT).show());
            }
        });
        thread.start();

    }
}
