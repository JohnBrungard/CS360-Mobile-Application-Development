package com.example.cs360p2johnbrungard;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/* Searches the available inventory and begins process of outputting results onto ListView */
public class SearchActivity extends AppCompatActivity {
    // Key variable initializations
    private ListView itemListView;
    EditText searchName;
    Button searchButton, clearButton;
    InventoryDatabase DB;
    boolean checkName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_inventory);

        // Key variable assignments
        searchName = findViewById(R.id.searchName);
        searchButton = findViewById(R.id.searchButton);
        clearButton = findViewById(R.id.clearButton);
        itemListView = findViewById(R.id.itemListView);
        DB = new InventoryDatabase(this);

        // Sets adapter to inflate contents onto ListView
        setItemAdapter();

        // Searches DB by name and projects results onto screen
        searchButton.setOnClickListener(view -> {
            String itemName = searchName.getText().toString();
            setItemAdapter();

            // If name EditText is empty
            if (itemName.equals("")) {
                Toast.makeText(SearchActivity.this, "Name Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            else {
                // Runs search operations on database on background thread
                searchThread(itemName, DB);

            }
        });

        // Clears contents of adapter as well as ListView
        clearButton.setOnClickListener(view -> {
            SearchAdapter searchAdapter = (SearchAdapter) itemListView.getAdapter();
            searchAdapter.clear();

            searchAdapter.notifyDataSetChanged();
        });

    }

    // Sets adapter with information to be sent to ListView
    private void setItemAdapter() {
        SearchAdapter searchAdapter = new SearchAdapter(getApplicationContext(), Item.itemArrayList);
        itemListView.setAdapter(searchAdapter);
    }

    // Inflates the app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            Intent intentLogout = new Intent(this, LoginActivity.class);
            startActivity(intentLogout);
            return true;
        }
        else if (item.getItemId() == R.id.permissions) {
            Intent intentPer = new Intent(this, PermissionsActivity.class);
            startActivity(intentPer);
            return true;
        }
        else if (item.getItemId() == R.id.moreInfo) {
            // Alert user
            Toast.makeText(SearchActivity.this, "For more information on B.I.S.: www.fakeDomain.com!"
                    , Toast.LENGTH_LONG).show();
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }

    public void searchThread (String name, InventoryDatabase database) {
        checkName = database.checkName(name);

        // If name does NOT exists in DB
        if (!checkName) {
            SearchActivity.this.runOnUiThread(() -> {
                // Notify user of failure
                Toast.makeText(SearchActivity.this, name +" was not found!"
                        , Toast.LENGTH_SHORT).show();
            });
        }
        // If name exists in DB
        else {
            // Prepare results to be cast onto UI
            database.readByName(name);

            SearchActivity.this.runOnUiThread(() -> searchName.setText(""));
        }

    }
}
