package com.example.cs360p2johnbrungard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/* Stores validated item credentials for Inventory Management */
public class InventoryDatabase extends SQLiteOpenHelper{
    // Names the database and version
    private static final String DBNAME = "Inventory.db";
    private static final int VERSION = 1;

    // Constructor
    public InventoryDatabase(Context context) {
        super(context, DBNAME, null, VERSION);
    }

    // Declares variables used in database
    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_COUNT= "count";
        private static final String COL_DATE = "date";
    }
    // Creates the database table for storing values
    @Override
    public void onCreate(SQLiteDatabase itemDB) {
        itemDB.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_COUNT + " text, " +
                ItemTable.COL_DATE + " text)");
    }

    // Deletes existing table to create upgraded version
    @Override
    public void onUpgrade(SQLiteDatabase itemDB, int older, int newer) {
        itemDB.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(itemDB);
    }

    // Adds item into the database table and returns a unique ID for said item
    public long createItem(String name, String count) {
        SQLiteDatabase itemDB = getWritableDatabase();
        // Trims and converts multi-space to single-space
        // Also capitalizes for uniformity in DB (collate nocase will prevent issue with this)
        name = name.trim().replaceAll("\\s+", " ").toUpperCase();

        // Retrieves today's date and converts it into a String
        SimpleDateFormat dateToday = new SimpleDateFormat("yyyyMMdd", Locale.US);
        String date = dateToday.format(new Date());

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_COUNT, count);
        values.put(ItemTable.COL_DATE, date);

        return itemDB.insert(ItemTable.TABLE, null, values);
    }

    // Allows user to query database for an item based on its name
    // Also is used to populate the ArrayList with content
    public void readByName(String name) {
        SQLiteDatabase itemDB = getReadableDatabase();
        // Trims and converts multi-space to single-space
        name = name.trim().replaceAll("\\s+", " ");

        // Searches the database with case insensitivity
        Cursor cursor = itemDB.rawQuery("Select * from " + InventoryDatabase.ItemTable.TABLE + " where name = ? collate nocase"
                , new String[] { name });

            // If cursor finds result
            if (cursor.moveToFirst()) {
                do {
                    long itemId = cursor.getLong(0);
                    String itemName = cursor.getString(1);
                    String itemCount = cursor.getString(2);
                    String itemDate = cursor.getString(3);

                    // Adds item and its credentials to ArrayList
                    Item item = new Item(itemId, itemName, itemCount, itemDate);
                    Item.itemArrayList.add(item);

                } while (cursor.moveToNext());
            }
            cursor.close();
    }

    // Queries for all contents of the DB
    // Also is used to populate the ArrayList with content
    public void readAll() {
        SQLiteDatabase itemDB = getReadableDatabase();

        // Searches the database with case insensitivity
        Cursor cursor = itemDB.rawQuery("Select * from " + InventoryDatabase.ItemTable.TABLE, null);

        // If cursor finds result
        if (cursor.moveToFirst()) {
            do {
                long itemId = cursor.getLong(0);
                String itemName = cursor.getString(1);
                String itemCount = cursor.getString(2);
                String itemDate = cursor.getString(3);

                // Adds item and its credentials to ArrayList
                Item item = new Item(itemId, itemName, itemCount, itemDate);
                Item.allItemArrayList.add(item);

            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    // Updates an item's count in the database by using its id
   public boolean updateCount(long id, String count) {
        SQLiteDatabase itemDB = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_COUNT, count);

        int rowsUpdated = itemDB.update(ItemTable.TABLE, values, "_id = ?",
                new String[] { Float.toString(id) });

        return rowsUpdated > 0;
   }

   // Removes an item from the database using its id
   public boolean removeItem(long id) {
        SQLiteDatabase itemDB = getWritableDatabase();

        int rowsDeleted = itemDB.delete(InventoryDatabase.ItemTable.TABLE, InventoryDatabase.ItemTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });

        return rowsDeleted > 0;
   }

   // Checks for name before executing CRUD operations
    public Boolean checkName (String name) {
        SQLiteDatabase itemDB = this.getReadableDatabase();
        // Trims and converts multi-space to single-space
        name = name.trim().replaceAll("\\s+", " ");

        // Searches the database with case insensitivity
        Cursor cursor = itemDB.rawQuery("Select * from " + InventoryDatabase.ItemTable.TABLE + " where name = ? collate nocase"
                , new String[] { name });

        // If item exists in DB
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        // If item does NOT exist in DB
        else {
            cursor.close();
            return false;
        }
    }

    public void checkCount() {
        SQLiteDatabase itemDB = getReadableDatabase();

        // Searches the database with case insensitivity
        Cursor cursor = itemDB.rawQuery("Select * from " + InventoryDatabase.ItemTable.TABLE, null);

        // If cursor finds result
        if (cursor.moveToFirst()) {
            do {
                long itemId = cursor.getLong(0);
                String itemName = cursor.getString(1);
                String itemCount = cursor.getString(2);
                String itemDate = cursor.getString(3);

                // If an item's count is 0
                if (itemCount.equals("0")) {
                    // Adds item and its credentials to ArrayList
                    Item item = new Item(itemId, itemName, itemCount, itemDate);
                    Item.zeroCountArrayList.add(item);
                }

            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
