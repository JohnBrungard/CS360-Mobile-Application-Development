package com.example.cs360p2johnbrungard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Objects;
import android.view.View;

/* Authenticates user credentials when logging into application */
public class LoginActivity extends AppCompatActivity {
    // Initialize key variables
    EditText username, password;
    Button register,signIn;
    boolean checkPass;
    LoginDatabase DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hides app bar for login screen
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.activity_main_login);

        // EditText assignments
        username = findViewById(R.id.enterUsername);
        password = findViewById(R.id.enterPassword);

        // Button assignments
        register = findViewById(R.id.registerButton);
        signIn = findViewById(R.id.signInButton);

        // DB object assignment
        DB = new LoginDatabase(this);

        // When the user clicks the register button
        register.setOnClickListener(view -> {
            // Users are redirected to the register screen
            Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(intent);
        });

        // When the user clicks the signIn button
        signIn.setOnClickListener(view -> {
            // EditTexts are converted to Strings.
            String uName = username.getText().toString();
            String pWord = password.getText().toString();

            // If username EditText is empty
            if (uName.equals("")) {
                Toast.makeText(LoginActivity.this, "Username Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If password EditText is empty
            else if (pWord.equals("")) {
                Toast.makeText(LoginActivity.this, "Password Field Cannot Be Empty!"
                        , Toast.LENGTH_SHORT).show();
            }
            // If all fields contain content
            else {
                // Run operations for database on background thread
                loginThread(uName, pWord, DB);

            }

        });
    }

    // Makes message visible for users trying to retrieve credentials
    public void showText(View view) {
        TextView showMsg = findViewById(R.id.retrieveCredentials);
        showMsg.setVisibility(View.VISIBLE);
    }

    // Puts operations involving database in a background thread
    public void loginThread (String user, String pass, LoginDatabase database) {
        Thread thread = new Thread(() -> {
            checkPass = database.checkPassword(user, pass);

            // Runs the following on the main thread
            LoginActivity.this.runOnUiThread(() -> {
                // If credentials are authenticated in the database
                if (checkPass) {
                    // User is redirected to home/inventory screen
                    Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                    startActivity(intent);
                }
                // If credentials are not authenticated in the database
                else {
                    // Notify users there is some problem in their input
                    Toast.makeText(LoginActivity.this, "Incorrect User/Password!"
                            , Toast.LENGTH_SHORT).show();
                }
            });
        });
        thread.start();

    }
}